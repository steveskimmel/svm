angular.module('starter.services', [])
